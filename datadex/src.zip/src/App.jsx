import React,{ useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Lista de Pokémon</h1>
      <select className='select select-bordered w-full max-w-xs mb-4' name="" id="">
        <option value="1-100">1-100</option>
        <option value="101-200">101-200</option>
        <option value="201-300">201-300</option>
        <option value="301-400">301-400</option>
        <option value="401-500">401-500</option>
        <option value="501-600">501-600</option>
        <option value="601-700">601-700</option>
        <option value="701-800">701-800</option>
        <option value="801-900">801-900</option>
        <option value="901-1000">901-1000</option>
      </select>

      <div className='grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4'>

      </div>
    </div>
  )
}

export default App
